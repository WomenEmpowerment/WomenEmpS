package com.lti.controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lti.model.Admin;
import com.lti.model.NGOReg;
import com.lti.model.Registration;
import com.lti.service.LoginService;

@Controller
@SessionAttributes("user")
public class LoginController {

	@Autowired
	private LoginService loginservice;

	@RequestMapping(path = "loginUser.lti", method = RequestMethod.POST)
	public String loginUser(@RequestParam("username") String username, @RequestParam("password") String password,
			ModelMap model,HttpSession session) {

		try {
			Registration login = loginservice.checkLoginUser(username, password);
			

			model.put("user", login);
			System.out.println("okkk");
			return "HomePage.jsp";

		}

		catch (Exception e) {
			System.out.println("not okk");
			model.put("message", "invalid username/password");
			return "UserLogin.jsp";

		}
	}
	
	@RequestMapping(path = "lngo.lti", method = RequestMethod.POST)
	public String loginNGO(@RequestParam("email") String email, @RequestParam("password") String password,
			ModelMap model) {

		try {
			NGOReg login = loginservice.checkLoginNGO(email,password);

			model.put("user", login);
			System.out.println("okkk");
			return "NGOHome.jsp";

		}

		catch (Exception e) {
			System.out.println("not okk");
			model.put("message", "invalid username/password");
			return "UserLogin.jsp";

		}
}
	
	
	
	@RequestMapping(path = "Admin.lti", method = RequestMethod.POST)
	public String loginAdmin(@RequestParam("username") String username, @RequestParam("password") String password,
			ModelMap model) {

		try {
			Admin login = loginservice.checkLoginAdmin(username,password);

			model.put("user", login);
			System.out.println("okkk");
			return "AdminCURD.jsp";

		}

		catch (Exception e) {
			System.out.println("not okk");
			model.put("message", "invalid username/password");
			return "AdminLogin.jsp";

		}
}
}
