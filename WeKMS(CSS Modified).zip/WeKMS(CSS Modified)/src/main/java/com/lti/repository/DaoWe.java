package com.lti.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.Accomodation;

import com.lti.model.AddEnrollmentAcc;
import com.lti.model.AddEnrollmentCourse;
import com.lti.model.Admin;
import com.lti.model.NGOAcc;
import com.lti.model.NGOCourse;
import com.lti.model.NGOReg;
import com.lti.model.Registration;

@Repository
public class DaoWe {

	@PersistenceContext
	private EntityManager entitymanager;

	@Transactional
	public void addEntry(Registration registration) {
		entitymanager.persist(registration);

	}

	@Transactional
	public void addEntryNgo(NGOReg ngoreg) {
		entitymanager.persist(ngoreg);
	}

	@Transactional
	public void addNgoAcc(NGOAcc ngoacc, int ngo_id) {
		NGOReg ngoreg = entitymanager.find(NGOReg.class, ngo_id);
		ngoacc.setNgoreg(ngoreg);
		entitymanager.persist(ngoacc);
	}

	@Transactional
	public void addNgoCourse(NGOCourse ngocourse, int ngo_id) {
		NGOReg ngoreg = entitymanager.find(NGOReg.class, ngo_id);
		ngocourse.setNgoreg(ngoreg);
		entitymanager.persist(ngocourse);
	}

	@Transactional
	public void addRegAcc(Accomodation accomodation, int regId) {
		Registration reg = entitymanager.find(Registration.class, regId);
		accomodation.setRegistration(reg);
		entitymanager.persist(accomodation);
	}

	@Transactional
	public Registration readUserLogin(String username, String password) {

		String qu = "select a from Registration as a where a.username=:username and a.password=:password";
		Query q1 = entitymanager.createQuery(qu);
		q1.setParameter("username", username);
		q1.setParameter("password", password);
		List list = q1.getResultList();

		Registration l1 = (Registration) q1.getSingleResult();
		return l1;
	}

	@Transactional
	public NGOReg readNGOLogin(String email, String password) {

		String qu = "select a from NGOReg as a where a.ngoEmail=:email and a.password=:password";
		Query q1 = entitymanager.createQuery(qu);
		q1.setParameter("email", email);
		q1.setParameter("password", password);
		List list = q1.getResultList();

		NGOReg l1 = (NGOReg) q1.getSingleResult();
		return l1;
	}

	@Transactional
	public Admin readNGOAdmin(String username, String password) {

		String qu = "select a from Admin as a where a.username=:username and a.password=:password";
		Query q1 = entitymanager.createQuery(qu);
		q1.setParameter("username", username);
		q1.setParameter("password", password);
		List list = q1.getResultList();

		Admin l1 = (Admin) q1.getSingleResult();
		return l1;
	}

	@Transactional
	public List<NGOCourse> getCourses() {
		String q1 = "select i from NGOCourse i";
		Query q = entitymanager.createQuery(q1);
		List<NGOCourse> obj = q.getResultList();
		return obj;
	}

	@Transactional
	public List<NGOAcc> findAccomodation(String city) {

		String qu = "select n from NGOAcc n where n.ngoacccity=:city";
		Query q1 = entitymanager.createQuery(qu);
		q1.setParameter("city", city);
		List<NGOAcc> accObj = q1.getResultList();

		System.out.println(accObj.toString());

		return accObj;
	}

	@Transactional
	public void addEnrollment(AddEnrollmentCourse addenrollmentcourse) {
		entitymanager.persist(addenrollmentcourse);

	}

	@Transactional
	public void enrollmentForAcc(AddEnrollmentAcc addenrollmentacc) {
		entitymanager.persist(addenrollmentacc);

	}

	@Transactional
	public List<NGOCourse> findCourse(String course1) {

		String qu = "select n from NGOCourse n where n.ngocname=:course";
		Query q1 = entitymanager.createQuery(qu);
		q1.setParameter("course", course1);
		List<NGOCourse> accObj1 = q1.getResultList();

		System.out.println(accObj1.toString());

		return accObj1;
	}

	@Transactional
	public List<Registration> Transfer(int id) {
		String qu = "select n.ngocname, n.ngocid  from NGOCourse n where n.ngocid=:id";
		Query q2 = entitymanager.createQuery(qu);
		q2.setParameter("id", id);
		List<Registration> accObj2 = q2.getResultList();
		System.out.println(accObj2.toString());
		return accObj2;

	}

	@Transactional
	public List<NGOReg> getDetails() {

		String qu = "select n from NGOReg n";
		Query q1 = entitymanager.createQuery(qu);

		List<NGOReg> accObj = q1.getResultList();
		System.err.println("REPO" + accObj.size());
		System.out.println(accObj.toString());

		return accObj;
	}

}
