package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.model.Accomodation;
import com.lti.model.AddEnrollmentAcc;
import com.lti.model.AddEnrollmentCourse;
import com.lti.model.NGOAcc;
import com.lti.model.NGOCourse;
import com.lti.model.NGOReg;
//import com.lti.model.Course;
import com.lti.model.Registration;
import com.lti.repository.DaoWe;

@Service
public class WomenE {

	@Autowired
	private DaoWe dao;

	/*
	 * @Autowired private MailService mailService;
	 */

	public void registerAdd(Registration registration) {

		dao.addEntry(registration);
		// mailService.send(registration.getEmail(),"Thankyou for
		// registering","For further details log in into your account");

	}

	public void addngoacc(NGOAcc ngoacc, int ngo_id) {
		dao.addEntry5(ngoacc, ngo_id);
	}

	public void addngocourse(NGOCourse ngocourse, int ngo_id) {
		dao.addEntry7(ngocourse, ngo_id);
	}

	public void registerAddNgo(NGOReg ngoreg) {

		dao.addEntryNgo(ngoreg);

	}

	public void registerAccomodation(Accomodation accomodation, int regId) {

		dao.addEntry1(accomodation, regId);
	}

	public List<NGOCourse> getCoursesS() {
		List<NGOCourse> obj1 = dao.getCourses();
		return obj1;

	}

	public List<NGOAcc> searchAcc(String city) {
		return dao.findAccomodation(city);

	}

	
	public void addEnrollmentS(AddEnrollmentCourse addenrollmentcourse) {
		dao.addEnrollment(addenrollmentcourse);
	}

	
	public void addEnrollmentAcc(AddEnrollmentAcc addenrollmentacc) {
		dao.enrollmentForAcc(addenrollmentacc);
	}
	
	
	
	public List<NGOCourse> searchCourse(String course1) {
		return dao.findCourse(course1);

	}

}