package com.lti.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.lti.model.Accomodation;
import com.lti.model.AddEnrollmentAcc;
import com.lti.model.AddEnrollmentCourse;
import com.lti.model.NGOAcc;
import com.lti.model.NGOCourse;
import com.lti.model.NGOReg;
import com.lti.model.Registration;
import com.lti.service.WomenE;

@Controller
// @SessionAttributes("reg_id")
public class WeController {

	@Autowired
	private WomenE w;



	@RequestMapping(path = "new.lti", method = RequestMethod.POST)
	public String register(Registration register, @RequestParam("docfile") MultipartFile m, HttpSession session) {

		System.out.println(m.getOriginalFilename());

		String path = "D:/uploads/";
		String finalpath = path + m.getOriginalFilename();

		try {
			m.transferTo(new File(finalpath));
		}

		catch (IOException e) {
			e.printStackTrace();
		}

		register.setDocfilename(m.getOriginalFilename());

		w.registerAdd(register);
		session.setAttribute("reg_id", register.getId());

		return "UserLogin.jsp";
	}

	@RequestMapping(path = "ngoreg.lti", method = RequestMethod.POST)
	public String xyz1(NGOReg ngoreg, HttpSession session) {

		w.registerAddNgo(ngoreg);
		session.setAttribute("ngo_id", ngoreg.getNgoId());
		return "NGOCourse.jsp";
	}

	@RequestMapping(path = "ngoacc.lti", method = RequestMethod.POST)
	public String xyz2(NGOAcc ngoacc, HttpSession session) {
		Integer ngoid = new Integer(session.getAttribute("ngo_id").toString());
		w.addngoacc(ngoacc, (int) ngoid);
		return "confirmation.jsp";
	}

	@RequestMapping(path = "ngocourse.lti", method = RequestMethod.POST)
	public String xyz3(NGOCourse ngocourse, HttpSession session) {
		Integer ngoid = new Integer(session.getAttribute("ngo_id").toString());
		w.addngocourse(ngocourse, (int) ngoid);
		return "confirmation.jsp";
	}

	@RequestMapping(path = "acc.lti", method = RequestMethod.POST)
	public void acc(Accomodation accomodation, HttpSession session) {

		Integer regId = new Integer(session.getAttribute("reg_id").toString());
		w.registerAccomodation(accomodation, (int) regId);

	}
	
	/*@RequestMapping(path = "userCourse.lti", method = RequestMethod.GET)
	
		public String getUserCourses(Map m)
		{
			List<NGOCourse> object = w.getCoursesS();
			m.put("ngocourse", object);
			return "UserCourse.jsp";
		}*/
	
	
	@RequestMapping(path = "accomodation.lti", method = RequestMethod.POST)
	
	public ModelAndView findAccomodation(@RequestParam String city)
	{
		List<NGOAcc> result = w.searchAcc(city);
		ModelAndView mav=new ModelAndView("search.jsp");
		mav.addObject("result", result);
		return mav;
	}
	
	
	//---------Enrollment---------------------------------------------------------
	@RequestMapping(path = "addEnrollment.lti", method = RequestMethod.POST)
	public String addEnroll(AddEnrollmentCourse addenrollmentcourse) {
		w.addEnrollmentS(addenrollmentcourse);
           return "confirmation.jsp";
	}
	
	@RequestMapping(path = "EnrollmentAccomodation.lti", method = RequestMethod.POST)
	public String enrollForAcc(AddEnrollmentAcc addenrollmentacc) {
		w.addEnrollmentAcc(addenrollmentacc);
           return "confirmation.jsp";
	}
	
	
	//-------------------------Fetching------------------------------------------------
	@RequestMapping(path = "UserCourseSearch.lti", method = RequestMethod.POST)
	
	public ModelAndView findCourse(@RequestParam String course1)
	{
		List<NGOCourse> result1 = w.searchCourse(course1);
		ModelAndView mav=new ModelAndView("FetchedData.jsp");
		mav.addObject("result1", result1);
		return mav;
	}

	
	
	@RequestMapping(path = "userCourse.lti", method = RequestMethod.GET)
	
	public String getUserCourses(Map m)
	{
		List<NGOCourse> object = w.getCoursesS();
		m.put("ngocourse", object);
		return "UserCourse.jsp";
	}
}
	


	