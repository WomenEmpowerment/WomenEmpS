package com.lti.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "NGO_COURSE")

public class NGOCourse {

	@Id
	@GeneratedValue
	@Column(name = "NGO_COURSE_ID")
	private int ngocid;

	@Column(name = "NGO_COURSE_NAME")
	private String ngocname;

	@Column(name = "START_DATE")
	private LocalDate ngocsd;

	@Column(name = "END_DATE")
	private LocalDate ngoced;

	@OneToOne
	@JoinColumn(name = "ID")
	private NGOReg ngoreg;

	public int getNgocid() {
		return ngocid;
	}

	public String getNgocname() {
		return ngocname;
	}

	public void setNgocname(String ngocname) {
		this.ngocname = ngocname;
	}

	public LocalDate getNgocsd() {
		return ngocsd;
	}

	public void setNgocsd(String ngocsd) {
		this.ngocsd = LocalDate.parse(ngocsd);
	}

	public LocalDate getNgoced() {
		return ngoced;
	}

	public void setNgoced(String ngoced) {
		this.ngoced = LocalDate.parse(ngoced);
	}

	public NGOReg getNgoreg() {
		return ngoreg;
	}

	public void setNgoreg(NGOReg ngoreg) {
		this.ngoreg = ngoreg;
	}

}