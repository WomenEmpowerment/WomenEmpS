package com.lti.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "ADD_ENROLLMENT_COURSE")

public class AddEnrollmentCourse {
	
	@Id
	@GeneratedValue
	@Column(name = "COURSE_ENROLLMENT_ID")
	private int courseEnrollId;
	
	@Column(name = "NGO_COURSE_ID")
	private int ngoCourseId ;
	
	@Column(name = "NGO_COURSE_NAME")
	private String ngoCourseName;

	@Column(name = "START_DATE")
	private String startD;

	@Column(name = "END_DATE")
	private String endD;
	

	@Column(name = "NGO_NAME")
	private String ngoName;
		

	@Column(name = "NGO_CITY")
	private String ngoCity;
	

	@Column(name = "NGO_EMAIL")
	private String ngoEmail;
	
	@Column(name = "NGO_PHONENO")
	private long ngoP;	
	
	@Column(name = "NGO_ADDRESS")
	private String ngoA; 	
		
		

	public int getCourseEnrollId() {
		return courseEnrollId;
	}

	public void setCourseEnrollId(int courseEnrollId) {
		this.courseEnrollId = courseEnrollId;
	}

	public int getNgoCourseId() {
		return ngoCourseId;
	}

	public void setNgoCourseId(int ngoCourseId) {
		this.ngoCourseId = ngoCourseId;
	}

	public String getNgoCourseName() {
		return ngoCourseName;
	}

	public void setNgoCourseName(String ngoCourseName) {
		this.ngoCourseName = ngoCourseName;
	}

	public String getStartD() {
		return startD;
	}

	public void setStartD(String startD) {
		this.startD = startD;
	}

	public String getEndD() {
		return endD;
	}

	public void setEndD(String endD) {
		this.endD = endD;
	}

	public String getNgoName() {
		return ngoName;
	}

	public void setNgoName(String ngoName) {
		this.ngoName = ngoName;
	}

	public String getNgoCity() {
		return ngoCity;
	}

	public void setNgoCity(String ngoCity) {
		this.ngoCity = ngoCity;
	}

	public String getNgoEmail() {
		return ngoEmail;
	}

	public void setNgoEmail(String ngoEmail) {
		this.ngoEmail = ngoEmail;
	}

	public long getNgoP() {
		return ngoP;
	}

	public void setNgoP(long ngoP) {
		this.ngoP = ngoP;
	}

	public String getNgoA() {
		return ngoA;
	}

	public void setNgoA(String ngoA) {
		this.ngoA = ngoA;
	}

	
	
	
	
	
}
