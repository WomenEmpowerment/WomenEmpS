package com.lti.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.lti.model.Accomodation;
import com.lti.model.NGOAcc;
import com.lti.model.NGOCourse;
import com.lti.model.NGOReg;
import com.lti.model.Registration;
import com.lti.service.WomenE;

@Controller
// @SessionAttributes("reg_id")
public class WeController {

	@Autowired
	private WomenE w;

	static int s;

	@RequestMapping(path = "new.lti", method = RequestMethod.POST)
	public String register(Registration register, @RequestParam("docfile") MultipartFile m, HttpSession session) {

		System.out.println(m.getOriginalFilename());

		String path = "D:/uploads/";
		String finalpath = path + m.getOriginalFilename();

		try {
			m.transferTo(new File(finalpath));
		}

		catch (IOException e) {
			e.printStackTrace();
		}

		register.setDocfilename(m.getOriginalFilename());

		w.registerAdd(register);
		session.setAttribute("reg_id", register.getId());

		return "UserLogin.jsp";
	}

	@RequestMapping(path = "ngoreg.lti", method = RequestMethod.POST)
	public String xyz1(NGOReg ngoreg, HttpSession session) {

		w.registerAddNgo(ngoreg);
		session.setAttribute("ngo_id", ngoreg.getNgoId());
		return "NGOLogin.jsp";
	}

	/*@RequestMapping(path = "ngoacc.lti", method = RequestMethod.POST)
	public String xyz2(NGOAcc ngoacc, HttpSession session) {
		Integer ngoid = new Integer(session.getAttribute("ngo_id").toString());
		w.addngoacc(ngoacc, (int) ngoid);
		return "confirmation.jsp";
	}*/

	@RequestMapping(path = "ngocourse.lti", method = RequestMethod.POST)
	public String xyz3(NGOCourse ngocourse, HttpSession session) {
		Integer ngoid = new Integer(session.getAttribute("ngo_id").toString());
		w.addngocourse(ngocourse, (int) ngoid);
		return "confirmation.jsp";
	}

	@RequestMapping(path = "acc.lti", method = RequestMethod.POST)
	public void acc(Accomodation accomodation, HttpSession session) {

		Integer regId = new Integer(session.getAttribute("reg_id").toString());
		w.registerAccomodation(accomodation, (int) regId);

	}
}

	