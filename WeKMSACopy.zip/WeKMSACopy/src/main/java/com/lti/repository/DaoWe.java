package com.lti.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.Accomodation;
//import com.lti.model.Course;

import com.lti.model.NGOAcc;
import com.lti.model.NGOCourse;
import com.lti.model.NGOReg;
import com.lti.model.Registration;

@Repository
public class DaoWe {

	@PersistenceContext
	private EntityManager entitymanager;

	@Transactional
	public void addEntry(Registration registration) {
		entitymanager.persist(registration);

	}

	@Transactional
	public void addEntryNgo(NGOReg ngoreg) {
		entitymanager.persist(ngoreg);
	}
	
	@Transactional
	public void addEntry5(NGOAcc ngoacc, int ngo_id) {
		NGOReg ngoreg= entitymanager.find(NGOReg.class, ngo_id);
		ngoacc.setNgoreg(ngoreg);
		entitymanager.persist(ngoacc);
	}
	
	@Transactional
	public void addEntry7(NGOCourse ngocourse, int ngo_id) {
		NGOReg ngoreg= entitymanager.find(NGOReg.class, ngo_id);
		ngocourse.setNgoreg(ngoreg);
		entitymanager.persist(ngocourse);
	}

	@Transactional
	public void addEntry1(Accomodation accomodation, int regId) {
		Registration reg = entitymanager.find(Registration.class, regId);
		accomodation.setRegistration(reg);
		entitymanager.persist(accomodation);
	}
	
	@Transactional
	public void addEntry4(NGOCourse ngocourse, int regId)
	{
		NGOReg reg = entitymanager.find(NGOReg.class, regId);
		ngocourse.setNgoreg(reg);
		entitymanager.persist(ngocourse);
	}
	
	@Transactional
	public Registration readUserLogin(String username,String password)
	{
		
		String qu="select a from Registration as a where a.username=:username and a.password=:password";
		Query q1=entitymanager.createQuery(qu);
		q1.setParameter("username",username);
		q1.setParameter("password",password);
		List list=q1.getResultList();
		
		Registration l1=(Registration)q1.getSingleResult();
		return l1;
	}
	
	@Transactional
	public NGOReg readNGOLogin(String email,String password)
	{
		
		String qu="select a from NGOReg as a where a.ngoEmail=:email and a.password=:password";
		Query q1=entitymanager.createQuery(qu);
		q1.setParameter("email",email);
		q1.setParameter("password",password);
		List list=q1.getResultList();
		
		NGOReg l1=(NGOReg)q1.getSingleResult();
		return l1;
	}
	
}

	