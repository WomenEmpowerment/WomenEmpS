package com.lti.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.model.Accomodation;
import com.lti.model.NGOAcc;
import com.lti.model.NGOCourse;
import com.lti.model.NGOReg;
//import com.lti.model.Course;
import com.lti.model.Registration;
import com.lti.repository.DaoWe;

@Service
public class WomenE {
	
	
	
	@Autowired
	private DaoWe dao;
	
	
	
	
	/*@Autowired
	private MailService mailService;*/
	
	public void registerAdd(Registration registration)
	{
		
		dao.addEntry(registration);
		//mailService.send(registration.getEmail(),"Thankyou for registering","For further details log in into your account");
		
	}
	
	public void addngoacc(NGOAcc ngoacc,int ngo_id)
	{
		dao.addEntry5 (ngoacc,ngo_id);
	}
	
	public void registerAddNgo(NGOReg ngoreg)
	{
		
		dao.addEntryNgo(ngoreg);
		//mailService.send(registration.getEmail(),"Thankyou for registering","For further details log in into your account");
		
	}
	
	public void addngocourse(NGOCourse ngocourse, int regId)
	{
		dao.addEntry4(ngocourse, regId);
	}
	
	public void registerAccomodation(Accomodation accomodation,int regId)
	{
		
		dao.addEntry1(accomodation,regId);
	}

}