package com.lti.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.lti.model.NGOAcc;
import com.lti.model.NGOReg;

public class Testt {

	@Test
	public void test() {
	NGOReg ngoreg= new NGOReg();
	ngoreg.setNgoAdd("sgcfyi");
	ngoreg.setNgoCity("gdsf");
	ngoreg.setNgoEmail("asdgsdc");
	ngoreg.setNgoName("hfhcvh");
	ngoreg.setNgoPhone(45798);
	
	NGOAcc a = new NGOAcc();
	a.setNgoacccity("tgdfg");
	a.setRoomAvail(10);
	a.setNgoreg(ngoreg);
	}

}
