package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "NGO_COURSE")

public class NGOCourse {

	@Id
	@GeneratedValue
	@Column(name = "NGO_COURSE_ID")
	private int ngocid;

	@Column(name = "NGO_COURSE_NAME")
	private int ngocname;

	@Column(name = "START_DATE")
	private String ngosd;

	@Column(name = "END_DATE")
	private String ngoed;

	@OneToOne
	@JoinColumn(name = "ID")
	private NGOReg ngoreg;

	public int getNgocid() {
		return ngocid;
	}

	public int getNgocname() {
		return ngocname;
	}

	public void setNgocname(int ngocname) {
		this.ngocname = ngocname;
	}

	public String getNgosd() {
		return ngosd;
	}

	public void setNgosd(String ngosd) {
		this.ngosd = ngosd;
	}

	public String getNgoed() {
		return ngoed;
	}

	public void setNgoed(String ngoed) {
		this.ngoed = ngoed;
	}

	public NGOReg getNgoreg() {
		return ngoreg;
	}

	public void setNgoreg(NGOReg ngoreg) {
		this.ngoreg = ngoreg;
	}

}