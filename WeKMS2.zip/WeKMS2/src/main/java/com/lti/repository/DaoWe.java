package com.lti.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.Accomodation;
//import com.lti.model.Course;

import com.lti.model.NGOAcc;
import com.lti.model.NGOCourse;
import com.lti.model.NGOReg;
import com.lti.model.Registration;

@Repository
public class DaoWe {

	@PersistenceContext
	private EntityManager entitymanager;

	@Transactional
	public void addEntry(Registration registration) {
		entitymanager.persist(registration);

	}

	@Transactional
	public void addEntryNgo(NGOReg ngoreg) {
		entitymanager.persist(ngoreg);
	}
	
	@Transactional
	public void addEntry5(NGOAcc ngoacc, int ngo_id) {
		NGOReg ngoreg= entitymanager.find(NGOReg.class, ngo_id);
		ngoacc.setNgoreg(ngoreg);
		entitymanager.persist(ngoacc);
	}

	@Transactional
	public void addEntry1(Accomodation accomodation, int regId) {
		Registration reg = entitymanager.find(Registration.class, regId);
		accomodation.setRegistration(reg);
		entitymanager.persist(accomodation);
	}
	
	@Transactional
	public void addEntry4(NGOCourse ngocourse, int regId)
	{
		NGOReg reg = entitymanager.find(NGOReg.class, regId);
		ngocourse.setNgoreg(reg);
		entitymanager.persist(ngocourse);
	}
	

	/*
	 * @Transactional public void addEntry2(Course course, int regId) {
	 * Registration reg = entitymanager.find(Registration.class, regId);
	 * course.setRegistration(reg); entitymanager.persist(course); }
	 */
	/*
	 * @Transactional public int log(String username, String password) { Query q
	 * = entitymanager.
	 * createQuery("select a from registration where a.username=:user and a.password=:password"
	 * );
	 * 
	 * 
	 * }
	 */
	/*
	 * @Transactional public Object fetchByObject(Class clazz,Object pk) {
	 * Object obj=entitymanager.find(clazz,pk); return obj; }
	 */

}

